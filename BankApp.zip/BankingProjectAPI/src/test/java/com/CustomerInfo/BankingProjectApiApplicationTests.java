package com.CustomerInfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingProjectApiApplicationTests {

	@Test
	void contextLoads() {
	}

}

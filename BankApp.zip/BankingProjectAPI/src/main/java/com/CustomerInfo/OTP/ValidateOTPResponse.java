package com.CustomerInfo.OTP;

public class ValidateOTPResponse {
	 private String responseCode;
	 private String Message;
	 
	 public String getResponseCode() {
		 return responseCode;
	 }
	 public void setResponseCode(String responseCode) {
		 this.responseCode = responseCode;
	 }
	 public String getMessage() {
		 return Message;
	 }
	 public void setMessage(String message) {
		 Message = message;
	 }	   
}
